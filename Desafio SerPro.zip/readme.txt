SerPro-Desafio

Fluxo que lista e detalhe ofertas de crédito, apresenta revisão das informações e permita-o realizar a contratação.

Used:
Coding Language: Javascript
Visual Studio Code https://code.visualstudio.com/
node.js https://nodejs.org/en/
readline-sync https://www.npmjs.com/package/readline-sync

Necessary:
Visual Studio Code, node.js, readline-sync

How to execute:
Download required software,
download Zip, unzip

In Visual Studio Code:
Open Terminal or Command Prompt.
Set Path to where File is Located (using cd).
Type “node SerProDesafio.js” and Click Enter