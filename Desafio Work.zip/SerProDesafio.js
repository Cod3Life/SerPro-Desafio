const readlineSync = require('readline-sync');

// Variables
let userName = "";
let yearlyIncome = 0;
let reviseAll = -1;

// language
let language = readlineSync.question("Please input English, Portuguese or German: ").toLowerCase();

// First Contact
if (language === "english") {
    userName = readlineSync.question("Please inform your name: ");
    console.log("Hi " + userName + "! Welcome to CréditoParaTodxs");
    yearlyIncome = readlineSync.question("Please inform your yearly income: ");
};
if (language === "portuguese") {
    userName = readlineSync.question("Por favor informe seu nome: ");
    console.log("Oi " + userName + "! Bem-vindo à CréditoParaTodxs");
    yearlyIncome = readlineSync.question("Por favor informe sua renda anual: ");
};
if (language === "german") {
    userName = readlineSync.question("Bitte informieren sie ihren Namen: ");
    console.log("Hi " + userName + "! Willkommen bei CréditoParaTodxs");
    yearlyIncome = readlineSync.question("Bitte informieren sie ihren Jahreseinkommen: ");
};
if (language !== "english" && language !== "german" && language !== "portuguese") {
    console.log("Sorry, wrong input!");
};

// Offers (de acordo com sua saúde financeira): 
// english
const safeCredit = "Our Safe Credit is... ";
const secureCredit = "Our Secure Credit is... ";
const proCredit = "Our Pro Credit is... ";
const maxCredit = "Our Max Credit is... ";
const ultraCredit = "Our Ultra Credit is... ";

// portuguese
const safeCreditP = "Nosso Safe Credit é... ";
const secureCreditP = "Nosso Secure Credit é... ";
const proCreditP = "Nosso Pro Credit é... ";
const maxCreditP = "Nosso Max Credit é... ";
const ultraCreditP = "Nosso Ultra Credit é... ";

// german
const safeCreditG = "Unser Safe Credit ist... ";
const secureCreditG = "Unser Secure Credit ist... ";
const proCreditG = "Unser Pro Credit ist... ";
const maxCreditG = "Unser Max Credit ist... ";
const ultraCreditG = "Unser Ultra Credit ist... ";

// Bought/Contracted
let safeContracted = -1;
let secureContracted = -1;
let proContracted = -1;
let maxContracted = -1;
let ultraContracted = -1;

// english
if (language === "english") {
    // has income
    if (yearlyIncome >= 5000 && yearlyIncome <= 30000) {
        console.log(safeCredit);
        let reviseSafe = readlineSync.question("Would you like to see our Safe Credit offer? Please input Y or N: ").toLowerCase();
        if (reviseSafe === "y") {
            console.log(safeCredit);
        }
    };
    
    if (yearlyIncome > 30000 && yearlyIncome <= 50000) {
        console.log("Our available offers for you are: Safe Credit and Secure Credit.");
        console.log("We recommend Secure Credit!");
        let twoOffers = readlineSync.question("Which would you like to see? Please input Safe or Secure: ").toLowerCase();
        if (twoOffers === "safe") {
            console.log(safeCredit);
        };
        if (twoOffers === "secure") {
            console.log(secureCredit);
        };
        if (twoOffers !== "safe" && twoOffers !== "secure") {
            console.log("If not, then...");
        };
    };
    
    if (yearlyIncome > 50000 && yearlyIncome <= 100000) {
        console.log("Our available offers for you are: Safe Credit, Secure Credit, Pro Credit and Max Credit.");
        console.log("We recommend Max Credit!");
        let fourOffers = readlineSync.question("Which would you like to see? Please input Safe, Secure, Pro or Max: ").toLowerCase();
        if (fourOffers === "safe") {
            console.log(safeCredit);
        };
        if (fourOffers === "secure") {
            console.log(secureCredit);
        };
        if (fourOffers === "pro") {
            console.log(proCredit);
        };
        if (fourOffers === "max") {
            console.log(maxCredit);
        };
        if (fourOffers !== "safe" && fourOffers !== "secure" && fourOffers !== "pro" && fourOffers !== "max") {
            console.log("Thank you, come again!");
        };
    };
    
    if (yearlyIncome > 100000) {
        console.log("Our available offers for you are: Safe Credit, Secure Credit, Pro Credit, Max Credit and Ultra Credit.");
        console.log("We recommend Ultra Credit!");
        let allOffers = readlineSync.question("Which would you like to see? Please input Safe, Secure, Pro, Max or Ultra: (Any other key to cancel) ").toLowerCase();
        if (allOffers === "safe") {
            console.log(safeCredit);
        };
        if (allOffers === "secure") {
            console.log(secureCredit);
        };
        if (allOffers === "pro") {
            console.log(proCredit);
        };
        if (allOffers === "max") {
            console.log(maxCredit);
        };
        if (allOffers === "ultra") {
            console.log(ultraCredit);
        };
        if (allOffers !== "safe" && allOffers !== "secure" && allOffers !== "pro" && allOffers !== "max" && allOffers !== "ultra") {
            console.log("Thank you, come again!");
        };
    };
    
    // catches negative income aswell
    if (yearlyIncome >= 5000 || yearlyIncome < 5000) {
        if (yearlyIncome >= 5000) {
            reviseAll = readlineSync.question("Would you like to see our other available offers? Please input Y or N: ").toLowerCase();   
        };
        if (yearlyIncome < 5000) {
            reviseAll = readlineSync.question("Would you like to see our available offers? Please input Y or N: ").toLowerCase();
        }
        //if (reviseAll === "n") {
        //    console.log("Thank you, come again!");
        //} 
        while (reviseAll === "y") {
            let seeOffers = readlineSync.question("Which would you like to see? Please input Safe, Secure, Pro, Max or Ultra: (Any other key to cancel) ").toLowerCase();
            if (seeOffers === "safe") {
                console.log(safeCredit);
            };
            if (seeOffers === "secure") {
                console.log(secureCredit);
            };
            if (seeOffers === "pro") {
                console.log(proCredit);
            };
            if (seeOffers === "max") {
                console.log(maxCredit);
            };
            if (seeOffers === "ultra") {
                console.log(ultraCredit);
            };
            if (seeOffers !== "safe" && seeOffers !== "secure" && seeOffers !== "pro" && seeOffers !== "max" && seeOffers !== "ultra") {
                reviseAll = -1;
                //console.log("Thank you, come again!");
            };
        };
        if (reviseAll !== "y" && reviseAll !== "n" && reviseAll !== -1) {
            console.log("Sorry, wrong input!");
        };
    };
    
    // contracts
    let contract = readlineSync.question("Do you wish to form a contract? Please input Y or N: ").toLowerCase();
    if (contract === "n") {
        console.log("Thank you, come again!");
    } 
    if (contract === "y") {
        let whichContract = readlineSync.question("Which credit would you like to contract? Please input Safe, Secure, Pro, Max or Ultra: (Any other key to cancel) ").toLowerCase();
        if (whichContract === "safe") {
            console.log(safeCredit);
            let cSafe = readlineSync.question("Are you sure? Please input Y or N: ").toLowerCase();
            if (cSafe === "y") {
                console.log("Contract has been realized! Thank you for trusting CréditoParaTodxs!");
                safeContracted = 1;
            };
            if (cSafe === "n") {
                console.log("Thank you, come again!");
            };
            if (cSafe !== "y" && cSafe !== "n") {
                console.log("Sorry, wrong input!");
            };
        };
        if (whichContract === "secure") {
            console.log(secureCredit);
            let cSecure = readlineSync.question("Are you sure? Please input Y or N: ").toLowerCase();
            if (cSecure === "y") {
                console.log("Contract has been realized! Thank you for trusting CréditoParaTodxs!");
                secureContracted = 1;
            };
            if (cSecure === "n") {
                console.log("Thank you, come again!");
            };
            if (cSecure !== "y" && cSecure !== "n") {
                console.log("Sorry, wrong input!");
            };
        };
        if (whichContract === "pro") {
            console.log(proCredit);
            let cPro = readlineSync.question("Are you sure? Please input Y or N: ").toLowerCase();
            if (cPro === "y") {
                console.log("Contract has been realized! Thank you for trusting CréditoParaTodxs!");
                proContracted = 1;
            };
            if (cPro === "n") {
                console.log("Thank you, come again!");
            };
            if (cPro !== "y" && cPro !== "n") {
                console.log("Sorry, wrong input!");
            };
        };
        if (whichContract === "max") {
            console.log(maxCredit);
            let cMax = readlineSync.question("Are you sure? Please input Y or N: ").toLowerCase();
            if (cMax === "y") {
                console.log("Contract has been realized! Thank you for trusting CréditoParaTodxs!");
                maxContracted = 1;
            };
            if (cMax === "n") {
                console.log("Thank you, come again!");
            };
            if (cMax !== "y" && cMax !== "n") {
                console.log("Sorry, wrong input!");
            };
        };
        if (whichContract === "ultra") {
            console.log(ultraCredit);
            let cUltra = readlineSync.question("Are you sure? Please input Y or N: ").toLowerCase();
            if (cUltra === "y") {
                console.log("Contract has been realized! Thank you for trusting CréditoParaTodxs!");
                ultraContracted = 1;
            };
            if (cUltra === "n") {
                console.log("Thank you, come again!");
            };
            if (cUltra !== "y" && cUltra !== "n") {
                console.log("Sorry, wrong input!");
            };
        };
        if (whichContract !== "safe" && whichContract !== "secure" && whichContract !== "pro" && whichContract !== "max" && whichContract !== "ultra") {
            contract = -1;
            console.log("Thank you, come again!");
        };
    };
    if (contract !== "y" && contract !== "n" && contract !== -1) {
        console.log("Sorry, wrong input!");
    };
};

// portuguese
if (language === "portuguese") {
    // has income
    if (yearlyIncome >= 5000 && yearlyIncome <= 30000) {
        console.log(safeCreditP);
        let reviseSafe = readlineSync.question("Voce gostaria de ver nossa oferta Safe Credit? Por favor informe S ou N: ").toLowerCase();
        if (reviseSafe === "s") {
            console.log(safeCreditP);
        }
    };
    
    if (yearlyIncome > 30000 && yearlyIncome <= 50000) {
        console.log("Nossa ofertas disponiveis para voce sao: Safe Credit e Secure Credit.");
        console.log("Nós recomendamos Secure Credit!");
        let twoOffers = readlineSync.question("Qual voce gostaria der ver? Por favor informe Safe ou Secure: ").toLowerCase();
        if (twoOffers === "safe") {
            console.log(safeCreditP);
        };
        if (twoOffers === "secure") {
            console.log(secureCreditP);
        };
        if (twoOffers !== "safe" && twoOffers !== "secure") {
            console.log("Se não, então...");
        };
    };
    
    if (yearlyIncome > 50000 && yearlyIncome <= 100000) {
        console.log("Nossa ofertas disponiveis para voce sao: Safe Credit, Secure Credit, Pro Credit e Max Credit.");
        console.log("Nós recomendamos Max Credit!");
        let fourOffers = readlineSync.question("Qual voce gostaria der ver? Por favor informe Safe, Secure, Pro ou Max: ").toLowerCase();
        if (fourOffers === "safe") {
            console.log(safeCreditP);
        };
        if (fourOffers === "secure") {
            console.log(secureCreditP);
        };
        if (fourOffers === "pro") {
            console.log(proCreditP);
        };
        if (fourOffers === "max") {
            console.log(maxCreditP);
        };
        if (fourOffers !== "safe" && fourOffers !== "secure" && fourOffers !== "pro" && fourOffers !== "max") {
            console.log("Obrigado! Até!");
        };
    };
    
    if (yearlyIncome > 100000) {
        console.log("Nossa ofertas disponiveis para voce são: Safe Credit, Secure Credit, Pro Credit, Max Credit e Ultra Credit.");
        console.log("Nós recomendamos Ultra Credit!");
        let allOffers = readlineSync.question("Qual voce gostaria der ver? Por favor informe Safe, Secure, Pro, Max ou Ultra: (Qualquer outra tecla para cancelar) ").toLowerCase();
        if (allOffers === "safe") {
            console.log(safeCreditP);
        };
        if (allOffers === "secure") {
            console.log(secureCreditP);
        };
        if (allOffers === "pro") {
            console.log(proCreditP);
        };
        if (allOffers === "max") {
            console.log(maxCreditP);
        };
        if (allOffers === "ultra") {
            console.log(ultraCreditP);
        };
        if (allOffers !== "safe" && allOffers !== "secure" && allOffers !== "pro" && allOffers !== "max" && allOffers !== "ultra") {
            console.log("Obrigado! Até!");
        };
    };
    
    // catches negative income aswell
    if (yearlyIncome >= 5000 || yearlyIncome < 5000) {
        if (yearlyIncome >= 5000) {
            reviseAll = readlineSync.question("Gostaria der ver you nossa outras ofertas disponiveis? Por favor informe S ou N: ").toLowerCase();   
        };
        if (yearlyIncome < 5000) {
            reviseAll = readlineSync.question("Gostaria der ver you nossa ofertas disponiveis? Por favor informe S ou N: ").toLowerCase();
        }
        while (reviseAll === "s") {
            let seeOffers = readlineSync.question("Qual voce gostaria der ver? Por favor informe Safe, Secure, Pro, Max ou Ultra: (Qualquer outra tecla para cancelar) ").toLowerCase();
            if (seeOffers === "safe") {
                console.log(safeCreditP);
            };
            if (seeOffers === "secure") {
                console.log(secureCreditP);
            };
            if (seeOffers === "pro") {
                console.log(proCreditP);
            };
            if (seeOffers === "max") {
                console.log(maxCreditP);
            };
            if (seeOffers === "ultra") {
                console.log(ultraCreditP);
            };
            if (seeOffers !== "safe" && seeOffers !== "secure" && seeOffers !== "pro" && seeOffers !== "max" && seeOffers !== "ultra") {
                reviseAll = -1;
            };
        };
        if (reviseAll !== "s" && reviseAll !== "n" && reviseAll !== -1) {
            console.log("Desculpe, entrada errada!");
        };
    };
    
    // contracts
    let contract = readlineSync.question("Voce deseja realizar um contrato? Por favor informe S ou N: ").toLowerCase();
    if (contract === "n") {
        console.log("Obrigado! Até!");
    } 
    if (contract === "s") {
        let whichContract = readlineSync.question("Qual credito voce gostaria de contratar? Por favor informe Safe, Secure, Pro, Max ou Ultra: (Qualquer outra tecla para cancelar) ").toLowerCase();
        if (whichContract === "safe") {
            console.log(safeCreditP);
            let cSafe = readlineSync.question("Tem certeza? Por favor informe S ou N: ").toLowerCase();
            if (cSafe === "s") {
                console.log("O contrato foi realizado! Obrigada pela confiança com CréditoParaTodxs!");
                safeContracted = 1;
            };
            if (cSafe === "n") {
                console.log("Obrigado! Até!");
            };
            if (cSafe !== "s" && cSafe !== "n") {
                console.log("Desculpe, entrada errada!");
            };
        };
        if (whichContract === "secure") {
            console.log(secureCreditP);
            let cSecure = readlineSync.question("Tem certeza? Por favor informe S ou N: ").toLowerCase();
            if (cSecure === "s") {
                console.log("O contrato foi realizado! Obrigada pela confiança com CréditoParaTodxs!");
                secureContracted = 1;
            };
            if (cSecure === "n") {
                console.log("Obrigado! Até!");
            };
            if (cSecure !== "s" && cSecure !== "n") {
                console.log("Desculpe, entrada errada!");
            };
        };
        if (whichContract === "pro") {
            console.log(proCreditP);
            let cPro = readlineSync.question("Tem certeza? Por favor informe S ou N: ").toLowerCase();
            if (cPro === "s") {
                console.log("O contrato foi realizado! Obrigada pela confiança com CréditoParaTodxs!");
                proContracted = 1;
            };
            if (cPro === "n") {
                console.log("Obrigado! Até!");
            };
            if (cPro !== "s" && cPro !== "n") {
                console.log("Desculpe, entrada errada!");
            };
        };
        if (whichContract === "max") {
            console.log(maxCreditP);
            let cMax = readlineSync.question("Tem certeza? Por favor informe S ou N: ").toLowerCase();
            if (cMax === "s") {
                console.log("O contrato foi realizado! Obrigada pela confiança com CréditoParaTodxs!");
                maxContracted = 1;
            };
            if (cMax === "n") {
                console.log("Obrigado! Até!");
            };
            if (cMax !== "s" && cMax !== "n") {
                console.log("Desculpe, entrada errada!");
            };
        };
        if (whichContract === "ultra") {
            console.log(ultraCreditP);
            let cUltra = readlineSync.question("Tem certeza? Por favor informe S ou N: ").toLowerCase();
            if (cUltra === "s") {
                console.log("O contrato foi realizado! Obrigada pela confiança com CréditoParaTodxs!");
                ultraContracted = 1;
            };
            if (cUltra === "n") {
                console.log("Obrigado! Até!");
            };
            if (cUltra !== "s" && cUltra !== "n") {
                console.log("Desculpe, entrada errada!");
            };
        };
        if (whichContract !== "safe" && whichContract !== "secure" && whichContract !== "pro" && whichContract !== "max" && whichContract !== "ultra") {
            contract = -1;
            console.log("Obrigado! Até!");
        };
    };
    if (contract !== "s" && contract !== "n" && contract !== -1) {
        console.log("Desculpe, entrada errada!");
    };
};

// german
if (language === "german") {
    // has income
    if (yearlyIncome >= 5000 && yearlyIncome <= 30000) {
        console.log(safeCreditG);
        let reviseSafe = readlineSync.question("Moechten Sie unser Angebot Safe Credit ansehen? Bitte J oder N eingeben: ").toLowerCase();
        if (reviseSafe === "j") {
            console.log(safeCreditG);
        }
    };
    
    if (yearlyIncome > 30000 && yearlyIncome <= 50000) {
        console.log("Unsere verfuegbaren Angebote fuer Sie sind: Safe Credit und Secure Credit.");
        console.log("Wir empfehlen Secure Credit!");
        let twoOffers = readlineSync.question("Welche moechten Sie sich ansehen? Bitt Safe oder Secure eingeben: ").toLowerCase();
        if (twoOffers === "safe") {
            console.log(safeCreditG);
        };
        if (twoOffers === "secure") {
            console.log(secureCreditG);
        };
        if (twoOffers !== "safe" && twoOffers !== "secure") {
            console.log("Wenn nicht, dann...");
        };
    };
    
    if (yearlyIncome > 50000 && yearlyIncome <= 100000) {
        console.log("Unsere verfuegbaren Angebote fuer Sie sind: Safe Credit, Secure Credit, Pro Credit und Max Credit.");
        console.log("Wir empfehlen Max Credit!");
        let fourOffers = readlineSync.question("Welche moechten Sie sich ansehen? Bitte Safe, Secure, Pro oder Max eingeben: ").toLowerCase();
        if (fourOffers === "safe") {
            console.log(safeCreditG);
        };
        if (fourOffers === "secure") {
            console.log(secureCreditG);
        };
        if (fourOffers === "pro") {
            console.log(proCreditG);
        };
        if (fourOffers === "max") {
            console.log(maxCreditG);
        };
        if (fourOffers !== "safe" && fourOffers !== "secure" && fourOffers !== "pro" && fourOffers !== "max") {
            console.log("Vielen Dank, beehren Sie uns bald wieder!");
        };
    };
    
    if (yearlyIncome > 100000) {
        console.log("Unsere verfuegbaren Angebote fuer Sie sind: Safe Credit, Secure Credit, Pro Credit, Max Credit und Ultra Credit.");
        console.log("Wir empfehlen Ultra Credit!");
        let allOffers = readlineSync.question("Welche moechten Sie sich ansehen? Bitte Safe, Secure, Pro, Max oder Ultra eingeben: (Zum abbrechen irgendeine taste eingeben) ").toLowerCase();
        if (allOffers === "safe") {
            console.log(safeCreditG);
        };
        if (allOffers === "secure") {
            console.log(secureCreditG);
        };
        if (allOffers === "pro") {
            console.log(proCreditG);
        };
        if (allOffers === "max") {
            console.log(maxCreditG);
        };
        if (allOffers === "ultra") {
            console.log(ultraCreditG);
        };
        if (allOffers !== "safe" && allOffers !== "secure" && allOffers !== "pro" && allOffers !== "max" && allOffers !== "ultra") {
            console.log("Vielen Dank, beehren Sie uns bald wieder!");
        };
    };
    
    // catches negative income aswell
    if (yearlyIncome >= 5000 || yearlyIncome < 5000) {
        if (yearlyIncome >= 5000) {
            reviseAll = readlineSync.question("Moechten Sie unsere anderen verfuegbaren Angebote ansehen? Bitte J oder N eingeben: ").toLowerCase();   
        };
        if (yearlyIncome < 5000) {
            reviseAll = readlineSync.question("Moechten Sie unsere verfuegbaren Angebote ansehen? Bitte J oder N eingeben: ").toLowerCase();
        }
        while (reviseAll === "j") {
            let seeOffers = readlineSync.question("Welche moechten Sie sich ansehen? Bitte Safe, Secure, Pro, Max oder Ultra eingeben: (Zum abbrechen irgendeine taste eingeben) ").toLowerCase();
            if (seeOffers === "safe") {
                console.log(safeCreditG);
            };
            if (seeOffers === "secure") {
                console.log(secureCreditG);
            };
            if (seeOffers === "pro") {
                console.log(proCreditG);
            };
            if (seeOffers === "max") {
                console.log(maxCreditG);
            };
            if (seeOffers === "ultra") {
                console.log(ultraCreditG);
            };
            if (seeOffers !== "safe" && seeOffers !== "secure" && seeOffers !== "pro" && seeOffers !== "max" && seeOffers !== "ultra") {
                reviseAll = -1;
            };
        };
        if (reviseAll !== "j" && reviseAll !== "n" && reviseAll !== -1) {
            console.log("Es tut uns leid, falsche Eingabe!");
        };
    };
    
    // contracts
    let contract = readlineSync.question("Moechten Sie einen Vertrag abschliessen? Bitte J oder N eingeben: ").toLowerCase();
    if (contract === "n") {
        console.log("Vielen Dank, beehren Sie uns bald wieder!");
    } 
    if (contract === "j") {
        let whichContract = readlineSync.question("Welchen Kredit moechten Sie abschliessen? Bitte Safe, Secure, Pro, Max oder Ultra: (Zum abbrechen irgendeine taste eingeben) ").toLowerCase();
        if (whichContract === "safe") {
            console.log(safeCreditG);
            let cSafe = readlineSync.question("Sind Sie sicher? Bitte J oder N eingeben: ").toLowerCase();
            if (cSafe === "j") {
                console.log("Der Vertrag ist abgeschlossen! Vielen dank fuer ihr Vertrauen in CréditoParaTodxs!");
                safeContracted = 1;
            };
            if (cSafe === "n") {
                console.log("Vielen Dank, beehren Sie uns bald wieder!");
            };
            if (cSafe !== "j" && cSafe !== "n") {
                console.log("Es tut uns leid, falsche Eingabe!");
            };
        };
        if (whichContract === "secure") {
            console.log(secureCreditG);
            let cSecure = readlineSync.question("Sind Sie sicher? Bitte J oder N eingeben: ").toLowerCase();
            if (cSecure === "j") {
                console.log("Der Vertrag ist abgeschlossen! Vielen dank fuer ihr Vertrauen in CréditoParaTodxs!");
                secureContracted = 1;
            };
            if (cSecure === "n") {
                console.log("Vielen Dank, beehren Sie uns bald wieder!");
            };
            if (cSecure !== "j" && cSecure !== "n") {
                console.log("Es tut uns leid, falsche Eingabe!");
            };
        };
        if (whichContract === "pro") {
            console.log(proCreditG);
            let cPro = readlineSync.question("Sind Sie sicher? Bitte J oder N eingeben: ").toLowerCase();
            if (cPro === "j") {
                console.log("Der Vertrag ist abgeschlossen! Vielen dank fuer ihr Vertrauen in CréditoParaTodxs!");
                proContracted = 1;
            };
            if (cPro === "n") {
                console.log("Vielen Dank, beehren Sie uns bald wieder!");
            };
            if (cPro !== "j" && cPro !== "n") {
                console.log("Es tut uns leid, falsche Eingabe!");
            };
        };
        if (whichContract === "max") {
            console.log(maxCreditG);
            let cMax = readlineSync.question("Sind Sie sicher? Bitte J oder N eingeben: ").toLowerCase();
            if (cMax === "j") {
                console.log("Der Vertrag ist abgeschlossen! Vielen dank fuer ihr Vertrauen in CréditoParaTodxs!");
                maxContracted = 1;
            };
            if (cMax === "n") {
                console.log("Vielen Dank, beehren Sie uns bald wieder!");
            };
            if (cMax !== "j" && cMax !== "n") {
                console.log("Es tut uns leid, falsche Eingabe!");
            };
        };
        if (whichContract === "ultra") {
            console.log(ultraCreditG);
            let cUltra = readlineSync.question("Sind Sie sicher? Bitte J oder N eingeben: ").toLowerCase();
            if (cUltra === "j") {
                console.log("Der Vertrag ist abgeschlossen! Vielen dank fuer ihr Vertrauen in CréditoParaTodxs!");
                ultraContracted = 1;
            };
            if (cUltra === "n") {
                console.log("Vielen Dank, beehren Sie uns bald wieder!");
            };
            if (cUltra !== "j" && cUltra !== "n") {
                console.log("Es tut uns leid, falsche Eingabe!");
            };
        };
        if (whichContract !== "safe" && whichContract !== "secure" && whichContract !== "pro" && whichContract !== "max" && whichContract !== "ultra") {
            contract = -1;
            console.log("Vielen Dank, beehren Sie uns bald wieder!");
        };
    };
    if (contract !== "j" && contract !== "n" && contract !== -1) {
        console.log("Es tut uns leid, falsche Eingabe!");
    };
};

// If contracted then save information (name, yearly income, which contract was contracted and date)
// in database as next step 

// Summary (in english just for example)
if (safeContracted === 1 || secureContracted === 1 || proContracted === 1 || maxContracted === 1 || ultraContracted === 1) {
    console.log("\nContractee: " + userName);
    console.log("\nIncome: " + yearlyIncome);
    if (safeContracted === 1) {
        console.log("Safe Credit");
    };
    if (secureContracted === 1) {
        console.log("Secure Credit");
    };
    if (proContracted === 1) {
        console.log("Pro Credit");
    };
    if (maxContracted === 1) {
        console.log("Max Credit");
    };
    if (ultraContracted === 1) {
        console.log("Ultra Credit");
    };
};